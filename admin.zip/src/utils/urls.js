export const baseUrl = "http://localhost:8000";
export const productUrl = baseUrl + "/products";
        